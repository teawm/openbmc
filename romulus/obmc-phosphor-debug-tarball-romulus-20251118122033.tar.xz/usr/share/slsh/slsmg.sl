import("slsmg");
provide("slsmg");
